//
//  ContentView.swift
//  Hackathon19GaucAMole
//
//  Created by Mohammed ALSarraf on 12/6/19.
//  Copyright © 2019 MasterCode Inc. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeScreen()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
